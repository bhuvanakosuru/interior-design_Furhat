package furhatos.app.jokebot.flow.main

import furhatos.app.jokebot.flow.Parent
import furhatos.nlu.common.*
import furhatos.flow.kotlin.*
import furhatos.gestures.Gestures
import furhatos.nlu.SimpleIntent
import furhatos.util.Language
import java.util.*



val ex : State = state{

}
// Current state
var current_state : State = ex


// ********************************************************
val negatives = listOf("don't", "wouldn't", "do not")


val otherUser = listOf("hello", "hey" , "hey furhat")

val confirmation : State = state{
    onEntry {
        furhat.listen()
    }
    onResponse{
        val res = it.text.toString()
        if(res.contains("yes")){
            goto(Start)
        }
        else{
            goto(current_state)
        }
    }
}


// ################################
val Start: State = state(Parent) {
    onEntry {
        furhat.ask("Hi there. What are you up to today?")
        delay(2000)
    }
    val user_response = listOf("new", "changing", "moving", "change", "relocate", "relocating")

    onResponse {
        val user_input = it.text
        when  {
            user_response.any{user_input.contains(it, ignoreCase = true)} -> {
                println("Got user response")
                //furhat.say("Let me help you out with it.")
                goto(InteriorDecor)
            }
            else -> {
                goto( end_conversation  )
            }
        }
    }
}



val InteriorDecor: State = state(Parent) {
    onEntry {
        furhat.ask("Let me help you out with it. What do you want to start with your room?")
    }

    onResponse {
        val userResponse = it.text
        println("User said: $userResponse")

        val responses = mapOf(
            "moving" to "Moving can be quite a task! Need any tips?",
            "renovate" to "Renovating is exciting! What changes do you have in mind?",
            "makeover" to "A makeover sounds fun! What’s your vision?",
            "relocating" to "Relocating is a big step! How can I help?",
            "redesign" to "Its good to change your environment for a refreshing feel",
            "apartment" to "Congratulations on the new apartment! What's first on your list?"
        )

        val user_response = responses.entries.find { userResponse.contains(it.key, ignoreCase = true) }
        val userDecision = it.text
        if(otherUser.any{userDecision.contains(it, ignoreCase = true)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }
        if (user_response != null) {
            furhat.say(user_response.value)
        }
        else {
            furhat.gesture(Gestures.Shake(2.0))
            furhat.say("I cannot find it in the list.")
            println("Response not found in the list")
            delay(2000)
            goto(Start)
        }

        delay(1000)
        goto(conversation)
    }

}



val conversation: State = state {
    onEntry {
        furhat.ask("Let's check your preferences. What style of room do you like to live in?")
    }

    onResponse {
        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it, ignoreCase = true)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }
        println("User said: $userResponse")

        val responses = mapOf(
            "traditional" to "That's a classic choice! Traditional styles often emphasize elegance.",
            "modern" to "Modern styles are sleek and functional. Great choice!",
            "contemporary" to "Contemporary designs are always in style. Very chic!",
            "rustic" to "Rustic styles bring a warm, cozy feel to a space.",
            "minimalist" to "Minimalist designs focus on simplicity and functionality.",
            "bohemian space" to "Bohemian spaces are vibrant and full of character!"
        )

        val user_response = responses.entries.find { userResponse.contains(it.key, ignoreCase = true) }
        if (user_response != null) {
            furhat.say(user_response.value)
        }
        else {
            furhat.say("That sounds interesting!")
        }

        furhat.say("Let's start with it")
        goto(start_with)


    }

}

val start_with: State = state {
    onEntry {
        //We shall first figure out about the walls. Do you have any ideas for it?
        furhat.ask("What shall I start suggesting with from the following: Walls, Flooring, Furniture")
        furhat.gesture(Gestures.Thoughtful)

        delay(2000)
    }

    onResponse{
        val user_input = it.text

        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it, ignoreCase = true)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }

        when{
            user_input.contains("wall") -> {
                goto(wall_suggestions)
            }

            user_input.contains("floor") -> {
                goto(flooring_suggestions)
            }
        }

    }
}

val wall_suggestions: State = state {
    onEntry {
        furhat.say("Ok, let me suggest you some ideas for your walls")
        delay(1000)
    }

    onResponse{
        val user_input = it.text
        furhat.say("You said $user_input")
        val userIdeas = mapOf(
            "paint" to "So we have to decide the colours",
            "wallpaper" to "Wallpapers are good and easy to finish"
        )


        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it, ignoreCase = true)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }

        
        val user_response = userIdeas.entries.find { user_input.contains(it.key, ignoreCase = true) }
        if (user_response != null) {
            furhat.say(user_response.value)
            furhat.ask("Here are some suggestions of colours based on your likes: \nYou like dark colours\nDo you want to paint your room with blue, red, brown, black?")

            val user_opinion = it.text
            onResponse{
                if (user_opinion.contains("no")){
                    furhat.gesture(Gestures.ExpressSad)
                }
            }
        }
    }
}


val flooring_suggestions: State = state {
    onEntry {
        furhat.gesture(Gestures.Smile)
        furhat.say("That's good to start")
        furhat.gesture(Gestures.BigSmile)
    }
}


/*
val newUser:State =state{
    onEntry {
        furhat.listen()
    }
    onResponse{
        if(it.text.contains("yes")) {
            goto(Start)
        }

        else{
            goto(current_state)
        }
    }
}
*/


val end_conversation: State = state {
    onEntry{
        furhat.gesture(Gestures.OpenEyes)
        furhat.say("Have a great day!")
    }
}