package furhatos.app.jokebot.setting

val maxNumberOfUsers = 2
val distanceToEngage = 1.0