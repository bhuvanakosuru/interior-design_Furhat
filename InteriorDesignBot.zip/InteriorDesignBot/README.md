# Jokebot
A root learning humour

## Description
A skill where the robot tell jokes and checks to see if you are smiling or not. 

## Usage
Max number of users is set to: 2
The smile detection only works on the physical robot where there is a camera feed