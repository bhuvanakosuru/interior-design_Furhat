package furhatos.app.jokebot.flow.main

import furhatos.app.jokebot.flow.Parent
import furhatos.flow.kotlin.*
import furhatos.gestures.Gestures
import java.io.File

val ex : State = state{
    onEntry { goto(conversation) }
}
// Current state
var current_state : State = ex


// ********************************************************
val negatives = listOf("don't", "wouldn't", "do not")

var userName: String? = null

val otherUser = listOf("hi", "hello", "hey" , "hey furhat")

/* Original code */
val confirmation : State = state{
    onEntry {
        furhat.listen()
    }
    onResponse{
        val res = it.text.toString()

        var user_agreed_takingNewUser = listOf("yes", "yeah", "ok")
        if(user_agreed_takingNewUser.any { res.contains(it) }) {
            goto(Start)
        }

        else if(negatives.any{res.contains(it)})  {
            goto(current_state)
        }

        else{
            goto(current_state)
        }
    }
}


// ********************************************************
val Start : State = state {
    onEntry {
        furhat.ask("Hi, I am InDe, your interior design robo assistant!")
        furhat.gesture(Gestures.BigSmile)
        furhat.gesture(Gestures.Blink)
    }
    onResponse{
        goto(Start2)
    }

}
val Start2: State = state {
    onEntry {
        //goto(askColorPreference)
        //goto(askFlooringPreference)
        //goto(end_conversation)
        furhat.ask("For new user, say NEW OR for old user say your ID", timeout = 3000)
        furhat.gesture(Gestures.Blink)
    }

    onResponse {
        userName = it.text.trim()
        println("Nice to meet you, $userName!")

        if (userName.equals("Nadeem", ignoreCase = true)) {
            furhat.gesture(Gestures.Oh)
            delay(500)
            furhat.say("welcome back, Nadeem!")
            val file = File("C:\\Users\\PNW_checkout\\AppData\\Local\\Programs\\furhat-sdk-desktop-launcher\\Tester\\src\\main\\kotlin\\furhatos\\app\\jokebot\\shami.txt")
            val content = file.readText()
            furhat.say("Your rating for our previous conversation was: $content")
            if(content.toInt() < 5){
                furhat.gesture(Gestures.Oh)
                furhat.say("Hope, you have a great experience this time as I try to improve my suggestions")
            }
            else{
                furhat.say("You seem you had a great experience last time!")
                furhat.gesture(Gestures.BigSmile)
            }
            current_state = ex
        }

        else if (userName.equals("jesse", ignoreCase = true)) {
            furhat.gesture(Gestures.Oh)
            delay(500)
            furhat.say("welcome back, Jesse!")
            val file = File("C:\\Users\\PNW_checkout\\AppData\\Local\\Programs\\furhat-sdk-desktop-launcher\\Tester\\src\\main\\kotlin\\furhatos\\app\\jokebot\\jeevana.txt")
            val content = file.readText()
            furhat.say("Your rating for our previous conversation was: $content")
            if(content.toInt() < 5){
                furhat.gesture(Gestures.Oh)
                furhat.say("I will try to improve this time")
            }
            else{
                furhat.say("You seem you had a great experience last time.")
                furhat.gesture(Gestures.BigSmile)
            }
            current_state = ex
        }

        else if (userName.equals("sam", ignoreCase = true)) {
            furhat.gesture(Gestures.Oh)
            delay(500)
            furhat.say("welcome back, Sam!")
            val file = File("C:\\Users\\PNW_checkout\\AppData\\Local\\Programs\\furhat-sdk-desktop-launcher\\Tester\\src\\main\\kotlin\\furhatos\\app\\jokebot\\shami.txt")
            val content = file.readText()
            furhat.say("Your rating for our previous conversation was: $content")
            if(content.toInt() < 5){
                furhat.gesture(Gestures.Oh)
                furhat.say("I will try to improvise my suggestions this time around")
            }
            else{
                furhat.say("You seem you had a great experience last time.")
                furhat.gesture(Gestures.BigSmile)
            }
            current_state = ex
        }

        else if (userName.equals("Kenny", ignoreCase = true)) {
            furhat.gesture(Gestures.Oh)
            delay(500)
            furhat.say("welcome back, Kenny!")
            val file = File("C:\\Users\\PNW_checkout\\AppData\\Local\\Programs\\furhat-sdk-desktop-launcher\\Tester\\src\\main\\kotlin\\furhatos\\app\\jokebot\\bhuvana.txt")
            val content = file.readText()
            furhat.say("Your rating for our previous conversation was: $content")
            if(content.toInt() < 5){
                furhat.gesture(Gestures.Oh)
                furhat.say("I will try not to disappoint this time")
            }
            else{
                furhat.say("You seem you had a great experience last time.")
                furhat.gesture(Gestures.BigSmile)
            }
            current_state = ex
        }

        else{
            furhat.say("Nice to meet you. I see you are a new user")
        }

        // Proceed to start conversation
        goto(Start1)
    }
}

val Start1: State = state(Parent) {
    onEntry {
        //furhat.say("Hi there! I’m here to help you make your space just right.")
        furhat.say("I’m here to help you make your space just right.")
        furhat.ask("Are you planning something new, " +
                    "like moving, redecorating, or just making a few updates?", timeout = 4000)
        delay(500)
        furhat.gesture(Gestures.BigSmile)
    }

    onResponse {
        val userInput = it.text
        val changeKeywords = listOf("new", "changing", "mov", "change", "relocat", "update",
                             "improve", "redecorat", "renovat", "makeover", "redesign", "apartment")

        if (changeKeywords.any { userInput.contains(it) }) {
            println("User input: $userInput")

            furhat.gesture(Gestures.Thoughtful)
            delay(500)
            furhat.say("Got it! I can help with ideas for your " +
                       "room layout, decor styles, and more.")

            val responses = mapOf(
                "mov" to listOf(
                    "Moving can be quite a task! I can give you some tips",
                    "Moving is exciting! I can help you with organizing or planning the new place?"
                ),
                "renovat" to listOf(
                    "Renovating is exciting! What changes do you have in mind?",
                    "Renovations can really transform a space. Any specific themes you like?"
                ),
                "makeover" to listOf(
                    "A makeover sounds fun! What’s your vision?",
                    "A room makeover can bring a fresh feel. Any specific ideas?"
                ),
                "relocat" to listOf(
                    "Relocating is a big step! How can I help?",
                    "Relocating means new possibilities. Let’s make it amazing!"
                ),
                "redesign" to listOf(
                    "Redesigning can breathe new life into a room. Any specific ideas?",
                    "A redesign is always refreshing! Tell me your plans."
                )
            )

            val matchedResponse = responses.entries.find { userInput.contains(it.key) }
            if (matchedResponse != null) {
                furhat.gesture(Gestures.Nod)
                delay(500)
                furhat.say(matchedResponse.value.random())
            }
            else {
                furhat.say("Sounds exciting! I'm here to help however I can.")
            }
            goto(conversation)
        }

        else {
            delay(300)
            furhat.gesture(Gestures.BrowRaise)
            delay(300)
            furhat.say("I can also help with smaller updates or brainstorming ideas.")
            delay(500)
            furhat.ask("Do you have anything specific in mind for your space?")

            onResponse {
                furhat.gesture(Gestures.Nod)
                delay(500)
                furhat.say("Got it! Let’s make it great together.")
                goto(conversation)
            }
        }
    }
}




val conversation: State = state {
    onEntry {
        furhat.ask("Let's check your preferences. What style of room do you like to live in?", timeout = 5000)
        delay(200)
        furhat.gesture(Gestures.Thoughtful)
    }

    onResponse {
        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }
        println("User said: $userResponse")

        val responses = mapOf(
            "traditional" to "That's a classic choice! Traditional styles often emphasize elegance.",
            "modern" to "Modern styles are sleek and functional. Great choice!",
            "contemporary" to "Contemporary designs are always in style. Very chic!",
            "rustic" to "Rustic styles bring a warm, cozy feel to a space.",
            "minimalist" to "Minimalist designs focus on simplicity and functionality.",
            "bohemian space" to "Bohemian spaces are vibrant and full of character!"
        )

        val user_response = responses.entries.find { userResponse.contains(it.key) }


        if (negatives.any{user_response.toString().contains(it)}) {
            furhat.say("Ok, let me know more about your preferences")
            goto(current_state)
        }

        if (user_response != null) {
            furhat.say(user_response.value)
        }
        else {
            furhat.say("That sounds interesting!")
        }

        furhat.say("Let's start with it")
        goto(start_with)
    }

}


val start_with: State = state {

    onEntry {

        //We shall first figure out about the walls. Do you have any ideas for it?
        furhat.ask("What shall I start suggesting with from the following: " +
                   "Walls, Flooring, Furniture", timeout = 5000)
        delay(500)
        furhat.gesture(Gestures.Thoughtful)
        delay(500)
    }

    onResponse{
        val user_input = it.text

        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }

        when{
            user_input.contains("wall") -> {
        //        goto(askFinishType)
                goto(askColorPreference)
            }


            user_input.contains("floor") -> {
                goto(askFlooringPreference)
            }

            user_input.contains("furniture") -> {
                goto(furniture_suggestions)
            }
        }
        furhat.say("I didn't recognize that")
        reentry()

    }
}


var enText: String? = null
var colorPreference: String? = null
var finishType: String? = null
var currentPair: Pair<String, String>? = null
var chosenCategory: String? = null

// List of common colors for validation
val validColors = listOf("blue", "red", "green", "yellow", "purple", "pink", "grey", "black", "white", "beige", "brown", "teal", "navy", "coral", "peach")

val suggestionsByCategory = mapOf(
    "Color Scheme" to listOf(
        Pair("How about a calming palette with a soft {colorPreference} shade? It can make the space feel open and relaxing.", "You could add a few wall-mounted shelves in matching tones for extra style and functionality."),
        Pair("Muted pastel colors like {colorPreference} can add a subtle and relaxing vibe, perfect for a serene environment.", "Pair them with white or natural wood furniture for a cohesive look."),
        Pair("A monochromatic scheme in {colorPreference} shades could bring a sophisticated, unified feel to the room.", "Consider adding texture through fabrics or rugs to keep the look interesting and balanced."),
        Pair("For a bold look, try a contrasting scheme with {colorPreference} as the main accent color against neutral tones.", "Use throw pillows, curtains, or rugs in {colorPreference} to pull the scheme together without overwhelming the space.")
    ),
    "Wallpaper" to listOf(
        Pair("Bold, patterned wallpaper in {colorPreference} could add unique character to your room and serve as a focal point.", "Consider adding wall art or framed prints that contrast with the wallpaper to create depth."),
        Pair("Textured {finishType} wallpaper could bring a sophisticated touch to your walls, adding both visual and tactile interest.", "Soft lighting can highlight the texture and add warmth, creating a cozy ambiance."),
        Pair("Floral or nature-inspired wallpaper in a {colorPreference} shade could bring a fresh and lively atmosphere.", "Complement it with simple furniture to let the wallpaper be the star of the room."),
        Pair("Consider a minimalist geometric pattern in {colorPreference} for a modern, stylish look that adds subtle design without overpowering the space.", "Balance the look with clean-lined furniture and minimal accessories for a cohesive appearance.")
    ),
    "Accent Wall" to listOf(
        Pair("How about an accent wall in a vibrant {colorPreference}? It can serve as a statement feature in the room.", "Complement it with neutral furniture to make the accent color stand out even more and create a balanced look."),
        Pair("Consider a rustic {finishType} panel wall for a cozy, cabin-inspired atmosphere that adds warmth and texture.", "Adding plants or greenery can enhance the rustic, natural feel and bring the outdoors in."),
        Pair("Try a two-tone accent wall with {colorPreference} and a complementary neutral shade for a creative, dynamic effect.", "Use simple decor pieces to avoid competing with the accent wall, letting it remain the focus of the room."),
        Pair("A chalkboard or magnetic accent wall could add functionality as well as a unique visual element, perfect for creative or family spaces.", "Accessorize with colorful magnets or frames to personalize the wall.")
    ),
    "Art and Decor" to listOf(
        Pair("A gallery wall with artwork might create a personalized space that reflects your taste and style.", "Add small shelves or picture ledges to change the artwork easily and keep the decor dynamic."),
        Pair("A geometric paint design with {colorPreference} could give your room a modern, artistic look.", "Complement it with modern furniture and metallic accents for a cohesive and stylish look."),
        Pair("Try incorporating wall sculptures or 3D art pieces to add texture and interest to flat walls.", "Position lighting strategically to cast shadows that enhance the dimensional effect of the art."),
        Pair("Hang large-scale abstract art in {colorPreference} tones to make a bold statement in the room.", "Pair with simple, minimal furniture to keep the art as the main focal point, ensuring it doesn’t feel cluttered.")
    )
)

//
//val askColorPreference: State = state {
//    onEntry {
//        furhat.ask("First, could you tell me your preferred wall color? Please answer with a single color.")
//    }
//
//    onResponse {
//        val userResponse = it.text.toLowerCase()
//        // Find a valid color within the user response
//        val detectedColor = validColors.find { color -> userResponse.contains(color) }
//
//        if (detectedColor != null) {
//            colorPreference = detectedColor
//            furhat.say("Got it! You prefer a $colorPreference color scheme.")
//            goto(askFinishType) // Move to the next state to ask for the finish type
//        } else {
//            furhat.say("I didn't recognize that as a color. Could you please specify a single color, like 'blue' or 'green'?")
//            reentry() // Re-ask for color if invalid
//        }
//    }
//
//}
val askColorPreference: State = state {
    onEntry {
        furhat.ask("First, could you tell me your preferred wall color? Please answer with a single color.", timeout = 3000)
    }

    onResponse {
        val userResponse = it.text


        // Check if the response is related to a new user greeting
        if (otherUser.any { greeting -> userResponse.contains(greeting) }) {
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }
        else {
            // Otherwise, proceed with color preference logic
            val detectedColor = validColors.find { color -> userResponse.contains(color) }

            if (detectedColor != null) {
                colorPreference = detectedColor
                furhat.say("Got it! You prefer a $colorPreference color scheme.")
                goto(askFinishType) // Move to the next state to ask for the finish type
            } else {
                furhat.say("I didn't recognize that as a color. Could you please specify a single color, like 'blue' or 'green'?")
                reentry() // Re-ask for color if invalid
            }
        }
    }
}

// State to ask for wall finish type
//val askFinishType: State = state {
//    onEntry {
//        furhat.ask("What type of wall finish are you interested in? Options could include paint, wallpaper, or wood paneling.")
//    }
//
//    onResponse {
//        finishType = it.text.toLowerCase()
//        furhat.say("Alright! A $finishType finish with a $colorPreference color scheme sounds interesting.")
//        goto(provideSuggestion) // Move to the next state to provide a suggestion
//    }
//}

val askFinishType: State = state {
    onEntry {
        furhat.ask("What type of wall finish are you interested in? Options could include paint, wallpaper, wood paneling, or art and decor.")
    }

    onResponse {
        //val userResponse = it.text
        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }

        // Define the valid finish types
        val validFinishes = listOf("paint", "wallpaper", "wood paneling", "art and decor")

        // Find a valid finish type within the user response
        val detectedFinish = validFinishes.find { finish -> userResponse.contains(finish) }

        if (detectedFinish != null) {
            finishType = detectedFinish
            furhat.say("Alright! A $finishType finish with a $colorPreference color scheme sounds interesting.")
            goto(provideSuggestion) // Move to the next state to provide a suggestion
        } else {
            furhat.say("I didn’t recognize that as a valid finish type. Could you please specify one of the following: paint, wallpaper, wood paneling, or art and decor?")
            reentry() // Re-ask for a valid finish type if none detected
        }
    }
}

// State to provide a suggestion based on user's choices
val provideSuggestion: State = state {
    onEntry {
        // Determine the suggestion category based on the finish type
        chosenCategory = when (finishType) {
            "paint" -> "Color Scheme"
            "wallpaper" -> "Wallpaper"
            "wood paneling" -> "Accent Wall"
            else -> "Art and Decor"
        }

        // Get suggestions for the chosen category
        val suggestions = suggestionsByCategory[chosenCategory]!!
        currentPair = suggestions.random()

        // Replace placeholders with actual values
        val suggestionText = currentPair!!.first
            .replace("{colorPreference}", colorPreference ?: "")
            .replace("{finishType}", finishType ?: "")
        val enhancementText = currentPair!!.second
            .replace("{colorPreference}", colorPreference ?: "")
            .replace("{finishType}", finishType ?: "")
        enText = enhancementText
        furhat.say("Based on your choices, here’s a suggestion for $chosenCategory: $suggestionText")
        delay(500)
        goto(temp)
    }
}

val temp: State = state {
    onEntry {
        furhat.ask("Did you like this idea?")
    }

    onResponse {
        //val userResponse = it.text.toLowerCase()
        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }
        if (userResponse.contains("yes") || userResponse.contains("yeah") || userResponse.contains("sure")) {
            furhat.say("Great choice! Here’s how you can enhance that: $enText")
            goto(askFlooringPreference) // Move to the next state
        } else {
            furhat.say("No problem! Let’s try another suggestion.")
            goto(provideSuggestion) // Go back to provide a new suggestion
        }
    }
}

//val flooring_suggestions: State = state {
//
//    // Array of paired flooring suggestions with two-step ideas
//    val suggestionPairs = arrayOf(
//        Pair("How about a classic hardwood floor for a timeless look?",
//            "You could pair it with a soft area rug to add warmth and comfort."),
//        Pair("Consider polished concrete for a modern, industrial vibe.",
//            "Adding floor cushions or a low-profile sofa could soften the look."),
//        Pair("Vinyl planks are both durable and budget-friendly.",
//            "They come in wood and stone finishes, perfect for a stylish yet practical choice."),
//        Pair("How about sleek ceramic tiles for a clean, polished finish?",
//            "Complement them with underfloor heating for added comfort."),
//        Pair("Laminate flooring can give you the look of wood at a lower cost.",
//            "You might consider a textured finish for a more realistic appearance."),
//        Pair("Carpet tiles offer a customizable and comfortable option.",
//            "You can mix and match colors to create patterns that suit your style."),
//        Pair("Bamboo flooring is eco-friendly and brings a natural, warm feel.",
//            "Pair it with light, neutral decor to enhance the organic vibe."),
//        Pair("A herringbone wood pattern can add elegance and sophistication.",
//            "Accent it with classic or vintage-style furniture for a cohesive look."),
//        Pair("Consider cork flooring for a soft, eco-friendly option.",
//            "It’s great for absorbing sound, making it ideal for cozy spaces."),
//        Pair("Stone tiles bring a rustic and durable feel to a room.",
//            "Adding natural wood furniture can enhance the earthy, natural theme.")
//    )
//
//    var suggestionIndex = (suggestionPairs.indices).random()
//    var currentPair = suggestionPairs[suggestionIndex]
//    var user_liked = false
//
//    onEntry {
//        furhat.say("Let's explore some flooring ideas! Here’s a suggestion: ${currentPair.first}")
//        delay(500)
//        furhat.ask("Do you like this idea, or would you prefer to hear another option?")
//        delay(300)
//        furhat.gesture(Gestures.Thoughtful)
//    }
//
//    val otherChoices = listOf("other", "another", "something else", "different")
//
//    onResponse {
//        val userResponse = it.text
//
//        if (otherChoices.any { userResponse.contains(it) }) {
//            while (!user_liked) {
//                var differentSuggestionIndex: Int
//                do {
//                    differentSuggestionIndex = (suggestionPairs.indices).random()
//                } while (differentSuggestionIndex == suggestionIndex)
//
//                currentPair = suggestionPairs[differentSuggestionIndex]
//                suggestionIndex = differentSuggestionIndex
//
//                furhat.say("Alright, here’s another idea: ${currentPair.first}")
//                furhat.gesture(Gestures.BrowRaise)
//                furhat.ask("Do you like this one, or would you like to hear another?")
//                delay(500)
//                furhat.gesture(Gestures.Thoughtful)
//
//
//                onResponse {
//                    val userLikes = it.text
//                    if (userLikes.contains("yes")) {
//                        user_liked = true
//                    }
//                }
//            }
//
//            furhat.say("Fantastic choice! Here’s how you can enhance that: ${currentPair.second}")
//        }
//        else {
//            furhat.say("Great choice! Here’s how you can enhance that: ${currentPair.second}")
//        }
//
//        goto(furniture_suggestions)
//    }
//}
//##############################
// Variables specific to flooring suggestions
var flooringPreference: String? = null
var flooringEnhancementText: String? = null
var currentFlooringPair: Pair<String, String>? = null
var chosenFlooringCategory: String? = null


val flooringSuggestionsByCategory = mapOf(
    "Wood" to listOf(
        Pair("How about a warm hardwood floor for a timeless look? Hardwood is durable and works well in both traditional and modern spaces.", "You could add a soft area rug to make it even cozier, especially around seating areas."),
        Pair("Consider using reclaimed wood for an eco-friendly choice that adds character and charm.", "Pair it with neutral walls to make the unique wood grains and textures stand out."),
        Pair("Wide-plank wood flooring gives a more contemporary feel and showcases the natural grain of the wood beautifully.", "Enhance the look by choosing a matte finish for a modern aesthetic."),
        Pair("Try a herringbone or chevron pattern for a sophisticated design that adds visual interest.", "Complement it with minimalist furniture to let the flooring be the focal point.")
    ),
    "Tile" to listOf(
        Pair("Sleek ceramic tiles can give a clean, modern look that’s easy to maintain.", "Consider adding underfloor heating for extra comfort, especially in colder months."),
        Pair("How about patterned tiles for a unique design that adds personality? Perfect for kitchens or bathrooms!", "Match them with simple furniture to avoid overwhelming the space."),
        Pair("Porcelain tiles are durable and water-resistant, making them ideal for high-traffic areas.", "Use a contrasting grout color to highlight the tiles and add a modern touch."),
        Pair("Natural stone tiles, like marble or travertine, add elegance and a timeless appeal.", "Seal the tiles to protect against moisture and pair with metallic or wood accents.")
    ),
    "Vinyl" to listOf(
        Pair("Vinyl flooring is budget-friendly, durable, and available in various styles, including wood and stone finishes.", "Choose a high-quality finish to make it look more natural and elegant."),
        Pair("Consider luxury vinyl planks that are both stylish and moisture-resistant, suitable for kitchens and bathrooms.", "Combine with accent rugs to add warmth and texture to your space."),
        Pair("Vinyl tiles in a checkerboard pattern can add a retro vibe to your room.", "Pair with minimalist furniture to balance out the bold look."),
        Pair("Textured vinyl flooring adds depth and interest while being comfortable underfoot.", "Choose a wood grain texture for a natural, rustic feel.")
    ),
    "Carpet" to listOf(
        Pair("Carpet tiles allow for a customizable look and are easy to replace if damaged, ideal for family spaces.", "Mix and match colors or patterns to create unique designs that reflect your style."),
        Pair("A plush carpet can add warmth and comfort, perfect for bedrooms or cozy living rooms.", "It pairs well with cozy furniture and soft lighting to create an inviting atmosphere."),
        Pair("Low-pile carpet is a practical choice for high-traffic areas and is easier to clean than high-pile options.", "Choose a neutral color to complement most decor styles and add colorful pillows or throws for accents."),
        Pair("Berber carpet, with its looped texture, offers durability and a natural look suitable for any room.", "Pair it with wooden furniture to create a balanced, rustic aesthetic.")
    )
)

// Initial state to ask for flooring preference
val askFlooringPreference: State = state {
    onEntry {
        furhat.ask("What type of flooring are you interested in? Options could include wood, tile, vinyl, or carpet.")
    }

    onResponse {

        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }

        // Define valid flooring types
        val validFlooringTypes = listOf("wood", "tile", "vinyl", "carpet")

        // Detect a valid flooring type within user response
        val detectedFlooring = validFlooringTypes.find { flooring -> userResponse.contains(flooring) }

        if (detectedFlooring != null) {
            flooringPreference = detectedFlooring
            furhat.say("Great choice! You’re interested in $flooringPreference flooring.")
            goto(provideFlooringSuggestion) // Move to the next state for flooring suggestion
        } else {
            furhat.say("I didn’t recognize that as a flooring type. Could you specify one of the following: wood, tile, vinyl, or carpet?")
            reentry() // Re-ask for a valid flooring type if none detected
        }
    }
}

// State to provide a flooring suggestion based on user's choices
val provideFlooringSuggestion: State = state {
    onEntry {
        // Determine the flooring suggestion category based on the preference
        chosenFlooringCategory = flooringPreference?.capitalize() ?: "Other"

        // Get suggestions for the chosen flooring category
        val flooringSuggestions = flooringSuggestionsByCategory[chosenFlooringCategory] ?: flooringSuggestionsByCategory["Other"]!!
        currentFlooringPair = flooringSuggestions.random()

        // Replace placeholders with actual values
        val flooringSuggestionText = currentFlooringPair!!.first
        flooringEnhancementText = currentFlooringPair!!.second

        furhat.say("Based on your choice, here’s a flooring idea: $flooringSuggestionText")
        delay(500)
        goto(tempFlooring)
    }
}

// State to ask if user likes the flooring suggestion
val tempFlooring: State = state {
    onEntry {
        furhat.ask("Did you like this flooring idea?")
    }

    onResponse {
      //  val userResponse = it.text.toLowerCase()
        val userResponse = it.text
        if(otherUser.any{userResponse.contains(it)}){
            furhat.say("Do you want to attend the new user?")
            current_state = thisState
            goto(confirmation)
        }
        if (userResponse.contains("yes") || userResponse.contains("yeah") || userResponse.contains("sure")) {
            furhat.say("Awesome! Here’s how you can enhance it: $flooringEnhancementText")
            goto(furniture_suggestions) // Move to the next section or flow
        } else {
            furhat.say("Alright, let’s try another flooring suggestion.")
            goto(provideFlooringSuggestion) // Go back to provide a new suggestion
        }
    }
}

//##############################


val furniture_suggestions: State = state {
    // Array of paired furniture suggestions with two-step ideas
    val suggestionPairs = arrayOf(
        Pair("How about a sleek sectional sofa for a modern living room?",
            "You could add a glass coffee table to keep the space feeling open."),
        Pair("Consider a vintage leather armchair for a touch of timeless style.",
            "Pair it with a floor lamp to create a cozy reading corner."),
        Pair("A modular sofa could give you the flexibility to rearrange the space as you like.",
            "Add some colorful throw pillows for a personalized touch."),
        Pair("How about a minimalist wooden dining table?",
            "Complement it with upholstered chairs for comfort and style."),
        Pair("A mid-century modern TV console could add a retro feel to your living room.",
            "Decorate it with plants or books to bring in color and texture."),
        Pair("A canopy bed frame could make your bedroom feel luxurious.",
            "Drape some light curtains around it for a soft, cozy effect."),
        Pair("Consider an extendable dining table for versatility when hosting guests.",
            "Pair it with matching benches or chairs that can be stored easily."),
        Pair("How about a tufted velvet sofa for a chic and sophisticated look?",
            "You could add a metallic side table to enhance the luxurious feel."),
        Pair("A corner desk could make an efficient workspace in a small room.",
            "Add floating shelves above for extra storage without taking up floor space."),
        Pair("Consider a reclining armchair for comfort in your living room.",
            "You could place it next to a small side table for convenience.")
    )

    var suggestionIndex = (suggestionPairs.indices).random()
    var currentPair = suggestionPairs[suggestionIndex]
    var user_liked = false

    onEntry {
        furhat.gesture(Gestures.Smile)
        furhat.say("Let's find the perfect furniture for your space! Here’s a suggestion: ${currentPair.first}")
        delay(500)
        furhat.gesture(Gestures.Thoughtful)
        delay(500)
        furhat.ask("Do you like this idea, or would you prefer to hear another option?")
    }

    val otherChoices = listOf("other", "another", "something else", "different")

    onResponse {
        val userResponse = it.text

        if (otherChoices.any { userResponse.contains(it) }) {
            while (!user_liked) {
                // Select a new random suggestion pair that isn’t the same as the last one
                var differentSuggestionIndex: Int
                do {
                    differentSuggestionIndex = (suggestionPairs.indices).random()
                } while (differentSuggestionIndex == suggestionIndex)

                currentPair = suggestionPairs[differentSuggestionIndex]
                suggestionIndex = differentSuggestionIndex

                furhat.gesture(Gestures.Nod)
                delay(1000)
                furhat.say("Alright, here’s another idea: ${currentPair.first}")

                furhat.ask("Do you like this one, or would you like to hear another?")
                furhat.gesture(Gestures.Thoughtful)
                delay(300)

                onResponse {
                    val userLikes = it.text
                    if (userLikes.contains("yes")) {
                        user_liked = true
                    }
                }
            }

            furhat.gesture(Gestures.BigSmile)
            furhat.say("Fantastic choice! Here’s how you can enhance that: ${currentPair.second}")
        } else {
            furhat.gesture(Gestures.Smile)
            furhat.say("Great choice! Here’s how you can enhance that: ${currentPair.second}")
        }

        goto(end_conversation)
    }
}




val end_conversation: State = state {
    onEntry {
        furhat.gesture(Gestures.OpenEyes)
        furhat.ask("Before we wrap up, could you please rate my suggestions on a scale of 1 to 5?")
    }

    onResponse {
        val userResponse = it.text
        val suggestionRating = userResponse.toIntOrNull()

        if (suggestionRating != null) {
            when (suggestionRating) {
                in 1..2 -> {
                    furhat.gesture(Gestures.ExpressSad)
                    furhat.say("Oh, I’m sorry to hear that! I’ll work on improving my suggestions.")
                }
                3 -> {
                    furhat.gesture(Gestures.Nod)
                    furhat.say("Thank you! I appreciate your feedback and will strive to make the experience even better.")
                }
                in 4..5 -> {
                    furhat.gesture(Gestures.BigSmile)
                    furhat.say("Thank you so much! I’m glad you found the suggestions helpful.")
                }
                else -> {
                    furhat.say("It seems like an unusual rating. Please feel free to share any specific feedback.")
                }
            }
            // Move to the next state to get the interaction rating
            goto(getInteractionRating(suggestionRating))
        } else {
            furhat.gesture(Gestures.ExpressSad)
            furhat.say("It looks like I didn't catch a number?")
            reentry()
        }
    }

    onNoResponse {
        furhat.gesture(Gestures.ExpressSad)
        furhat.say("No worries! Feel free to reach out if you have more feedback. Thank you for using our service!")
        furhat.gesture(Gestures.CloseEyes)
    }
}

fun getInteractionRating(suggestionRating: Int): State = state {
    onEntry {
        furhat.ask("And how would you rate your experience interacting with me, on a scale of 1 to 5?")
    }

    onResponse {
        val interactionResponse = it.text
        val interactionRating = interactionResponse.toIntOrNull()

        if (interactionRating != null) {
            furhat.say("Thank you for sharing your thoughts!")
            // Log both ratings in rate.csv
            val file = File("C:\\Users\\PNW_checkout\\AppData\\Local\\Programs\\furhat-sdk-desktop-launcher\\Tester\\src\\main\\kotlin\\furhatos\\app\\jokebot\\util\\rate.csv")
            file.appendText("$userName,$suggestionRating,$interactionRating\n")

            furhat.gesture(Gestures.BigSmile)
            furhat.say("Thank you for using our service! Have a wonderful day!")
            furhat.gesture(Gestures.CloseEyes)
        } else {
            furhat.say("It seems like I didn't catch a valid rating?")
            reentry()
        }
    }

    onNoResponse {
        furhat.gesture(Gestures.ExpressSad)
        furhat.say("No worries! Feel free to reach out if you have more feedback. Thank you for using our service!")
        furhat.gesture(Gestures.CloseEyes)
    }
}
