package furhatos.app.jokebot.setting

val maxNumberOfUsers = 3
val distanceToEngage = 1.0